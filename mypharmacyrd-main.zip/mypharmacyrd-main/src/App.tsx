/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageCircle, 
  MapPin, 
  Phone, 
  Clock, 
  History, 
  ShieldCheck, 
  Users, 
  Stethoscope, 
  Pill, 
  HeartPulse, 
  Sparkles, 
  ChevronRight, 
  Instagram, 
  Star,
  Menu,
  X,
  ArrowRight,
  Zap,
  Activity,
  Thermometer,
  Wind,
  PlusCircle,
  Droplets,
  Smile,
  Car,
  Calendar
} from 'lucide-react';

const WHATSAPP_LINK = "https://wa.me/18298272407";
const GOOGLE_MAPS_LINK = "https://www.google.com/maps/search/?api=1&query=plaza+paseo+del+mar+Av+Alemania+Punta+Cana+23000";

const translations = {
  es: {
    nav: { home: "Inicio", legacy: "Legado", facilities: "Instalaciones", contact: "Contacto" },
    hero: {
      badge: "Excelencia Farmacéutica desde 1984",
      title: "40 años de tradición, ahora en Punta Cana",
      desc: "My Pharmacy RD nace de una historia familiar que comenzó en Mallorca, España. Durante cuatro décadas ofrecimos confianza y cuidado. Hoy continuamos ese legado en el Caribe.",
      whatsapp: "WhatsApp Directo",
      location: "Cómo llegar",
      legacy_title: "Legado Familiar",
      legacy_desc: "Continuamos la tradición de la Farmacia Elena Álvaro Garcés de Mallorca, España."
    },
    features: {
      title: "En My Pharmacy encuentras",
      item1: "Abiertos los 7 días de la semana",
      item2: "Máxima precisión",
      item3: "Area de estar",
      item4: "Parqueo disponible"
    },
    facilities: {
      title: "Nuestras Instalaciones",
      subtitle: "Un espacio moderno y acogedor diseñado para brindarte la mejor atención y comodidad."
    },
    history: {
      title: "Nuestra historia",
      desc1: "My Pharmacy RD nace del legado de la Farmacia Elena Álvaro Garcés en Magaluf, Palma de Mallorca, un negocio familiar que durante 40 años fue referente en una de las zonas turísticas más importantes de la isla.",
      desc2: "Hoy continuamos esa tradición en Punta Cana con los mismos valores: servicio, confianza y cercanía.",
      cta: "Conoce el Legado",
      full_title: "Una historia familiar que cruza generaciones",
      quote1: "“My Pharmacy RD nace de una historia familiar marcada por el trabajo, la vocación de servicio y el compromiso con la salud.”",
      full_p1: "Durante 40 años, la familia Álvaro Garcés desarrolló su trayectoria en el sector farmacéutico a través de la Farmacia Elena Álvaro Garcés, ubicada en Magaluf, Palma de Mallorca (España), una de las zonas turísticas más importantes de la isla.",
      full_p2: "A lo largo de cuatro décadas, esta farmacia se convirtió en un verdadero referente en la zona, atendiendo a residentes, trabajadores y visitantes de todo el mundo. Más que un establecimiento, fue un punto de confianza y cercanía para muchas personas.",
      full_p3: "En ese entorno familiar se aprendió que una farmacia no es solo un lugar donde se dispensan medicamentos. Es un espacio donde se construyen relaciones, donde se escucha a las personas y donde cada cliente recibe orientación con responsabilidad.",
      full_p4: "Hoy, My Pharmacy RD representa la continuidad de una historia familiar dedicada al cuidado de las personas, llevando consigo la misma filosofía que dio origen a todo: servir con cercanía, generar confianza y cuidar la salud de cada cliente como parte de nuestra familia.",
      final_quote: "“De Mallorca al Caribe, el mismo compromiso con tu salud.”"
    },
    trust: {
      title: "Una farmacia basada en la confianza",
      desc: "My Pharmacy cree que una farmacia debe ser mucho más que un punto de venta. Debe ser un lugar donde las personas se sientan escuchadas, orientadas y atendidas con profesionalidad.",
      items: ["Atención cercana", "Orientación responsable", "Productos de calidad", "Servicio pensado para la comunidad de Punta Cana"],
      cta: "WhatsApp Directo"
    },
    contact: {
      title: "Contacto",
      subtitle: "Tu salud, nuestra historia.",
      address: "plaza paseo del mar, Av. Alemania, Punta Cana 23000",
      phone: "(829) 827-2407",
      hours: "9:00 AM – 10:30 PM (Abierto todos los días)",
      cta_maps: "Cómo llegar",
      cta_wa: "WhatsApp",
      google_title: "Farmacia en Punta Cana",
      google_reviews: "(Google Reviews)",
      google_open: "Abierto ⋅ Cierra a las 10:30 PM"
    },
    footer: {
      desc: "“Una farmacia con historia familiar, ahora cerca de ti en Punta Cana. 40 años de tradición cuidando de tu salud.”",
      explore: "Explorar",
      contact: "Contacto",
      rights: "De Mallorca al Caribe.",
      privacy: "Privacidad"
    }
  },
  en: {
    nav: { home: "Home", legacy: "Legacy", facilities: "Facilities", contact: "Contact" },
    hero: {
      badge: "Pharmaceutical Excellence since 1984",
      title: "40 years of tradition, now in Punta Cana",
      desc: "My Pharmacy RD was born from a family history that began in Mallorca, Spain. For four decades we offered trust and care. Today we continue that legacy in the Caribbean.",
      whatsapp: "Direct WhatsApp",
      location: "How to get here",
      legacy_title: "Family Legacy",
      legacy_desc: "We continue the tradition of the Elena Álvaro Garcés Pharmacy from Mallorca, Spain."
    },
    features: {
      title: "At My Pharmacy you find",
      item1: "Open 7 days a week",
      item2: "Maximum precision",
      item3: "Lounge area",
      item4: "Parking available"
    },
    facilities: {
      title: "Our Facilities",
      subtitle: "A modern and welcoming space designed to provide you with the best care and comfort."
    },
    history: {
      title: "Our Story",
      desc1: "My Pharmacy RD was born from the legacy of the Elena Álvaro Garcés Pharmacy in Magaluf, Palma de Mallorca, a family business that for 40 years was a reference in one of the most important tourist areas of the island.",
      desc2: "Today we continue that tradition in Punta Cana with the same values: service, trust, and proximity.",
      cta: "Meet the Legacy",
      full_title: "A family story that crosses generations",
      quote1: "“My Pharmacy RD was born from a family story marked by work, a vocation for service, and a commitment to health.”",
      full_p1: "For 40 years, the Álvaro Garcés family developed their career in the pharmaceutical sector through the Elena Álvaro Garcés Pharmacy, located in Magaluf, Palma de Mallorca (Spain), one of the most important tourist areas of the island.",
      full_p2: "Over four decades, this pharmacy became a true reference in the area, serving residents, workers, and visitors from all over the world. More than an establishment, it was a point of trust and proximity for many people.",
      full_p3: "In that family environment, it was learned that a pharmacy is not just a place where medicines are dispensed. It is a space where relationships are built, where people are listened to, and where each customer receives guidance with responsibility.",
      full_p4: "Today, My Pharmacy RD represents the continuity of a family story dedicated to caring for people, carrying with it the same philosophy that gave rise to everything: serving with proximity, generating trust, and caring for the health of each customer as part of our family.",
      final_quote: "“From Mallorca to the Caribbean, the same commitment to your health.”"
    },
    trust: {
      title: "A pharmacy based on trust",
      desc: "My Pharmacy believes that a pharmacy should be much more than a point of sale. It should be a place where people feel heard, guided, and cared for with professionalism.",
      items: ["Close attention", "Responsible guidance", "Quality products", "Service designed for the Punta Cana community"],
      cta: "Direct WhatsApp"
    },
    contact: {
      title: "Contact",
      subtitle: "Your health, our story.",
      address: "plaza paseo del mar, Av. Alemania, Punta Cana 23000",
      phone: "(829) 827-2407",
      hours: "9:00 AM – 10:30 PM (Open every day)",
      cta_maps: "How to get there",
      cta_wa: "WhatsApp",
      google_title: "Pharmacy in Punta Cana",
      google_reviews: "(Google Reviews)",
      google_open: "Open ⋅ Closes at 10:30 PM"
    },
    footer: {
      desc: "“A pharmacy with family history, now near you in Punta Cana. 40 years of tradition caring for your health.”",
      explore: "Explore",
      contact: "Contact",
      rights: "From Mallorca to the Caribbean.",
      privacy: "Privacy"
    }
  }
};

const WhatsAppIcon = ({ size = 24, className = "" }: { size?: number; className?: string }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className}
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
  </svg>
);

const NavItem = ({ href, children, onClick }: { href: string; children: React.ReactNode; onClick?: () => void }) => (
  <a 
    href={href} 
    onClick={onClick}
    className="text-slate-600 hover:text-pharmacy-green font-medium transition-colors duration-200"
  >
    {children}
  </a>
);

const Logo = () => (
  <div className="flex items-center gap-4 group cursor-pointer">
    <div className="relative w-48 h-16 flex items-center justify-center overflow-hidden">
      <img 
        src="https://i.imgur.com/KgW57sg.png" 
        alt="My Pharmacy Logo" 
        className="w-full h-full object-contain"
        referrerPolicy="no-referrer"
      />
    </div>
    <div className="h-8 w-[1px] bg-slate-200 hidden sm:block" />
    <span className="text-xs font-bold text-slate-400 tracking-[0.3em] uppercase leading-none hidden sm:block">Punta Cana • RD</span>
  </div>
);

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [lang, setLang] = useState<'es' | 'en'>('es');

  const t = translations[lang];

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true },
    transition: { duration: 0.6 }
  };

  const LanguageSwitcher = () => (
    <div className="flex items-center gap-2 bg-white/50 backdrop-blur-sm p-1 rounded-full border border-slate-200">
      <button 
        onClick={() => setLang('es')}
        className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${lang === 'es' ? 'bg-pharmacy-green text-white shadow-md' : 'hover:bg-slate-100'}`}
        title="Español"
      >
        <span className="text-xs font-bold">ES</span>
      </button>
      <button 
        onClick={() => setLang('en')}
        className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${lang === 'en' ? 'bg-pharmacy-green text-white shadow-md' : 'hover:bg-slate-100'}`}
        title="English"
      >
        <span className="text-xs font-bold">EN</span>
      </button>
    </div>
  );

  return (
    <div className="min-h-screen font-sans selection:bg-pharmacy-green/20">
      {/* Floating WhatsApp Button */}
      <a 
        href={WHATSAPP_LINK} 
        target="_blank" 
        rel="noopener noreferrer" 
        className="whatsapp-float flex items-center justify-center"
        aria-label="WhatsApp"
      >
        <WhatsAppIcon size={32} className="text-white" />
      </a>

      {/* Header */}
      <header className={`glass-header transition-all duration-500 ${scrolled ? 'py-3 shadow-xl' : 'py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <Logo />

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            <NavItem href="#home">{t.nav.home}</NavItem>
            <NavItem href="#historia">{t.nav.legacy}</NavItem>
            <NavItem href="#instalaciones">{t.nav.facilities}</NavItem>
            <NavItem href="#contacto">{t.nav.contact}</NavItem>
            <LanguageSwitcher />
            <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="btn-purple py-2.5 px-6 text-sm">
              <WhatsAppIcon size={18} />
              WhatsApp
            </a>
          </nav>

          {/* Mobile Menu Toggle */}
          <div className="flex items-center gap-4 md:hidden">
            <LanguageSwitcher />
            <button className="text-slate-900" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-t border-slate-100 overflow-hidden"
            >
              <div className="flex flex-col p-6 gap-4">
                <NavItem href="#home" onClick={() => setIsMenuOpen(false)}>{t.nav.home}</NavItem>
                <NavItem href="#historia" onClick={() => setIsMenuOpen(false)}>{t.nav.legacy}</NavItem>
                <NavItem href="#instalaciones" onClick={() => setIsMenuOpen(false)}>{t.nav.facilities}</NavItem>
                <NavItem href="#contacto" onClick={() => setIsMenuOpen(false)}>{t.nav.contact}</NavItem>
                <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="btn-primary w-full mt-2">
                  <WhatsAppIcon size={20} />
                  WhatsApp
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main>
        {/* Hero Section */}
        <section id="home" className="relative pt-24 pb-40 overflow-hidden">
          <div className="absolute top-0 right-0 -z-10 w-2/3 h-full bg-white rounded-l-[200px] hidden lg:block shadow-2xl shadow-black/5" />
          <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-20 items-center">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1 }}
            >
              <div className="flex items-center gap-3 mb-8">
                <span className="w-12 h-[1px] bg-pharmacy-purple/30"></span>
                <span className="text-pharmacy-purple font-display font-bold italic tracking-widest text-xs uppercase">
                  {t.hero.badge}
                </span>
              </div>
              <h1 className="section-title mb-8">
                {t.hero.title.split(',')[0]}, <br />
                <span className="luxury-underline italic font-medium">{t.hero.title.split(',')[1]}</span>
              </h1>
              <p className="text-xl text-slate-500 mb-12 leading-relaxed max-w-xl font-light">
                {t.hero.desc}
              </p>
              <div className="flex flex-col sm:flex-row gap-6">
                <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="btn-purple text-lg px-10">
                  <WhatsAppIcon size={22} />
                  {t.hero.whatsapp}
                </a>
                <a href={GOOGLE_MAPS_LINK} target="_blank" rel="noopener noreferrer" className="btn-secondary text-lg px-10">
                  <MapPin size={22} />
                  {t.hero.location}
                </a>
              </div>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.2, ease: "easeOut" }}
              className="relative"
            >
              <div className="oval-mask aspect-[4/5] overflow-hidden shadow-2xl border-[12px] border-white">
                <img 
                  src="https://i.imgur.com/YRzJnfF.jpeg" 
                  alt="My Pharmacy RD Profesional" 
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-1000"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -bottom-12 -left-12 bg-white/80 backdrop-blur-md p-10 rounded-[40px] shadow-2xl border border-white/50 hidden md:block max-w-xs">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-14 h-14 bg-pharmacy-purple/10 rounded-full flex items-center justify-center text-pharmacy-purple">
                    <History size={28} />
                  </div>
                  <span className="font-display font-bold text-slate-900 italic">{t.hero.legacy_title}</span>
                </div>
                <p className="text-sm text-slate-500 leading-relaxed">{t.hero.legacy_desc}</p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* En My Pharmacy encuentras (CruzMed Style) */}
        <section className="py-32 bg-white">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div {...fadeIn} className="text-center mb-20">
              <h2 className="section-title mb-4">{t.features.title}</h2>
              <div className="w-24 h-[1px] bg-pharmacy-green mx-auto" />
            </motion.div>
            
            <div className="grid lg:grid-cols-2 gap-20 items-center">
              <div className="space-y-12">
                {[
                  { icon: Clock, text: t.features.item1 },
                  { icon: Calendar, text: t.features.item2 },
                  { icon: Smile, text: t.features.item3 },
                  { icon: Car, text: t.features.item4 }
                ].map((item, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, x: -30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="flex items-center gap-8 group"
                  >
                    <div className="w-20 h-20 bg-pharmacy-green/10 rounded-2xl flex items-center justify-center text-pharmacy-green group-hover:bg-pharmacy-green group-hover:text-white transition-all duration-500 shadow-sm">
                      <item.icon size={36} />
                    </div>
                    <span className="text-2xl font-display font-bold text-slate-800 italic group-hover:text-pharmacy-green transition-colors">{item.text}</span>
                  </motion.div>
                ))}
              </div>
              
              <div className="flex justify-center lg:justify-end">
                <div className="grid grid-cols-3 gap-4 w-fit">
                  <div className="w-32 h-32 bg-transparent"></div>
                  <div className="w-32 h-32 bg-pharmacy-green rounded-xl shadow-lg"></div>
                  <div className="w-32 h-32 bg-transparent"></div>
                  
                  <div className="w-32 h-32 bg-pharmacy-green rounded-xl shadow-lg"></div>
                  <div className="w-32 h-32 bg-pharmacy-green/80 rounded-xl shadow-lg"></div>
                  <div className="w-32 h-32 bg-pharmacy-green rounded-xl shadow-lg"></div>
                  
                  <div className="w-32 h-32 bg-transparent"></div>
                  <div className="w-32 h-32 bg-pharmacy-green rounded-xl shadow-lg"></div>
                  <div className="w-32 h-32 bg-transparent"></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Nuestra Historia (Resumen) */}
        <section className="py-32 bg-pharmacy-cream">
          <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-20 items-center">
            <motion.div {...fadeIn} className="relative">
              <div className="oval-mask overflow-hidden shadow-2xl">
                <img 
                  src="https://i.imgur.com/TQEuj7s.jpeg" 
                  alt="Historia Familiar My Pharmacy" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute top-1/2 -right-10 w-40 h-40 bg-pharmacy-green rounded-full flex items-center justify-center text-white shadow-2xl border-8 border-pharmacy-cream hidden lg:flex">
                <History size={48} />
              </div>
            </motion.div>
            <motion.div {...fadeIn} transition={{ delay: 0.2 }}>
              <h2 className="section-title mb-8">{t.history.title}</h2>
              <p className="text-xl text-slate-500 mb-10 leading-relaxed font-light">
                {t.history.desc1}
              </p>
              <p className="text-lg text-slate-500 mb-12 leading-relaxed font-light">
                {t.history.desc2}
              </p>
              <a href="#historia-completa" className="btn-secondary w-fit">
                {t.history.cta}
              </a>
            </motion.div>
          </div>
        </section>

        {/* Valores */}
        <section className="py-24 bg-pharmacy-green text-white">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid md:grid-cols-3 gap-12 text-center">
              {[
                { icon: ShieldCheck, title: "Confianza", desc: "40 años de trayectoria nos avalan." },
                { icon: Users, title: "Cercanía", desc: "Trato familiar y personalizado." },
                { icon: Sparkles, title: "Profesionalidad", desc: "Asesoramiento experto en cada consulta." }
              ].map((val, i) => (
                <motion.div 
                  key={i}
                  {...fadeIn}
                  transition={{ delay: i * 0.1 }}
                >
                  <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6 backdrop-blur-sm">
                    <val.icon size={36} />
                  </div>
                  <h3 className="font-display font-bold text-2xl mb-3">{val.title}</h3>
                  <p className="text-white/80 text-lg">{val.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Ubicación Card */}
        <section className="py-24 bg-slate-50">
          <div className="max-w-4xl mx-auto px-6">
            <motion.div {...fadeIn} className="card-premium p-10 flex flex-col md:flex-row gap-10 items-center">
              <div className="flex-1">
                <h2 className="font-display text-3xl font-bold mb-6">{t.nav.contact}</h2>
                <div className="space-y-4 mb-8">
                  <div className="flex items-start gap-3">
                    <MapPin className="text-pharmacy-green shrink-0 mt-1" size={20} />
                    <div>
                      <p className="font-bold text-slate-900">My Pharmacy RD</p>
                      <p className="text-slate-500">{t.contact.address}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="text-pharmacy-green shrink-0" size={20} />
                    <p className="text-slate-500">{t.contact.phone}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock className="text-pharmacy-green shrink-0" size={20} />
                    <p className="text-slate-500">{t.contact.hours}</p>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <a href={GOOGLE_MAPS_LINK} target="_blank" rel="noopener noreferrer" className="btn-primary">
                    <MapPin size={20} />
                    {t.contact.cta_maps}
                  </a>
                  <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="btn-secondary">
                    <MessageCircle size={20} />
                    {t.contact.cta_wa}
                  </a>
                </div>
              </div>
              <div className="w-full md:w-64 h-64 rounded-2xl overflow-hidden shadow-inner border border-slate-200">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3780.46823456789!2d-68.42345678901234!3d18.67890123456789!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTjCsDQwJzQ0LjAiTiA2OMKwMjUnMjQuNCJX!5e0!3m2!1sen!2sdo!4v1234567890123" 
                  width="100%" 
                  height="100%" 
                  style={{ border: 0 }} 
                  allowFullScreen 
                  loading="lazy" 
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Google Maps Location"
                ></iframe>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Nuestra Historia (Full) */}
        <section id="historia-completa" className="py-32 bg-white">
          <div className="max-w-4xl mx-auto px-6">
            <motion.div {...fadeIn} className="text-center mb-20">
              <h2 className="section-title mb-6">{t.history.full_title}</h2>
              <div className="w-24 h-[1px] bg-pharmacy-purple mx-auto" />
            </motion.div>
            
            <motion.div {...fadeIn} className="font-serif text-2xl text-slate-600 space-y-10 leading-relaxed text-center italic font-light">
              <p>{t.history.quote1}</p>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-8 my-16">
              <motion.div {...fadeIn} className="oval-mask overflow-hidden shadow-xl h-64">
                <img src="https://images.unsplash.com/photo-1585421514738-01798e348b17?w=900&auto=format&fit=crop&q=60" alt="Compromiso Médico" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </motion.div>
              <motion.div {...fadeIn} transition={{ delay: 0.2 }} className="oval-mask overflow-hidden shadow-xl h-64 mt-12">
                <img src="https://images.unsplash.com/photo-1582719471384-894fbb16e074?w=900&auto=format&fit=crop&q=60" alt="Calidad Farmacéutica" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </motion.div>
            </div>

            <motion.div {...fadeIn} className="mt-16 space-y-8 text-lg text-slate-500 font-light leading-relaxed">
              <p>{t.history.full_p1}</p>
              <p>{t.history.full_p2}</p>
              <p>{t.history.full_p3}</p>
              <p>{t.history.full_p4}</p>
            </motion.div>

            <motion.div {...fadeIn} className="mt-24 p-16 bg-pharmacy-cream rounded-[60px] text-center border border-black/5 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-pharmacy-green" />
              <p className="font-serif text-4xl md:text-5xl font-light text-slate-900 italic mb-12">
                {t.history.final_quote}
              </p>
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="btn-purple mx-auto w-fit text-xl px-12">
                <WhatsAppIcon size={24} />
                {t.history.cta}
              </a>
            </motion.div>
          </div>
        </section>

        {/* Nuestras Instalaciones */}
        <section id="instalaciones" className="py-32 bg-pharmacy-cream">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div {...fadeIn} className="text-center mb-20">
              <h2 className="section-title mb-4">{t.facilities.title}</h2>
              <p className="text-slate-500 max-w-2xl mx-auto font-light text-lg">{t.facilities.subtitle}</p>
            </motion.div>
            
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                {[
                  "https://i.imgur.com/TBLDKAx.jpeg",
                  "https://lh3.googleusercontent.com/p/AF1QipMcHWALlJWADR2lGubOlXCwXP6Il71ds4IJvO7f=s1360-w1360-h1020-rw",
                  "https://lh3.googleusercontent.com/p/AF1QipMgOZkB4IJ7rzJYZH0Dy-lvFCePZPgSqAxYo5WX=s1360-w1360-h1020-rw",
                  "https://lh3.googleusercontent.com/p/AF1QipO_9A7d4nHdJPFROvNkEEwPlSPB3HZ2s5oBzset=s1360-w1360-h1020-rw"
                ].map((img, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.2 }}
                  className="rounded-[40px] overflow-hidden shadow-2xl h-[500px] border-8 border-white group"
                >
                  <img 
                    src={img} 
                    alt={`Instalación ${i + 1}`} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                    referrerPolicy="no-referrer"
                  />
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Confianza */}
        <section className="py-32 overflow-hidden bg-white">
          <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-20 items-center">
            <motion.div {...fadeIn}>
              <h2 className="section-title mb-8">{t.trust.title.split(' confianza')[0]} <span className="italic">confianza</span></h2>
              <p className="text-xl text-slate-500 mb-10 leading-relaxed font-light">
                {t.trust.desc}
              </p>
              <div className="space-y-6 mb-12">
                {t.trust.items.map((item, i) => (
                  <div key={i} className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-pharmacy-green/10 rounded-full flex items-center justify-center text-pharmacy-green">
                      <ShieldCheck size={20} />
                    </div>
                    <span className="font-display font-medium text-slate-700 italic">{item}</span>
                  </div>
                ))}
              </div>
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="btn-purple w-fit">
                <WhatsAppIcon size={20} />
                {t.trust.cta}
              </a>
            </motion.div>
            <motion.div {...fadeIn} className="relative">
              <div className="flex gap-6 overflow-x-auto pb-8 snap-x no-scrollbar cursor-grab active:cursor-grabbing">
                {[
                  "https://i.imgur.com/A8x7MQC.jpeg",
                  "https://images.unsplash.com/photo-1580281657527-47f249e8f4df?w=900&auto=format&fit=crop&q=60",
                  "https://images.unsplash.com/photo-1580281658223-9b93f18ae9ae?w=900&auto=format&fit=crop&q=60",
                  "https://images.unsplash.com/photo-1739289696449-cba3a5ef085d?w=900&auto=format&fit=crop&q=60",
                  "https://i.imgur.com/DR43yza.jpeg"
                ].map((img, i) => (
                  <div key={i} className="min-w-[300px] md:min-w-[450px] h-[550px] rounded-[40px] overflow-hidden shadow-2xl snap-center shrink-0 border-8 border-white group">
                    <img 
                      src={img} 
                      alt={`Confianza ${i + 1}`} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                      referrerPolicy="no-referrer" 
                    />
                  </div>
                ))}
              </div>
              <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 flex gap-3">
                {[0, 1, 2, 3, 4].map((i) => (
                  <div key={i} className="w-3 h-3 rounded-full bg-pharmacy-green/30" />
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Contacto & Google Business Profile Style */}
        <section id="contacto" className="py-24">
          <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12">
            {/* Business Card Style */}
            <motion.div {...fadeIn} className="bg-white rounded-[40px] shadow-2xl border border-slate-100 overflow-hidden">
              <div className="bg-pharmacy-green p-10 text-white">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-pharmacy-green font-bold text-3xl">M</div>
                  <div>
                    <h2 className="font-display text-3xl font-bold leading-none">My Pharmacy RD</h2>
                    <p className="text-white/80 mt-2">{t.contact.subtitle}</p>
                  </div>
                </div>
              </div>
              <div className="p-10 space-y-8">
                <div className="grid gap-6">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center text-pharmacy-green shrink-0">
                      <MapPin size={20} />
                    </div>
                    <p className="text-slate-600">{t.contact.address}</p>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center text-pharmacy-green shrink-0">
                      <Phone size={20} />
                    </div>
                    <p className="text-slate-600">{t.contact.phone}</p>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center text-pharmacy-green shrink-0">
                      <Clock size={20} />
                    </div>
                    <p className="text-slate-600">{t.contact.hours}</p>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="btn-primary flex-1">
                    <WhatsAppIcon size={20} />
                    {t.contact.cta_wa}
                  </a>
                  <a href={GOOGLE_MAPS_LINK} target="_blank" rel="noopener noreferrer" className="btn-secondary flex-1">
                    <MapPin size={20} />
                    {t.contact.cta_maps}
                  </a>
                </div>
              </div>
            </motion.div>

            {/* Google Business Profile Style Card */}
            <motion.div {...fadeIn} transition={{ delay: 0.2 }} className="bg-white rounded-2xl shadow-lg border border-slate-200 p-8">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">My Pharmacy RD</h3>
                  <p className="text-slate-500">{t.contact.google_title}</p>
                  <div className="flex items-center gap-1 mt-2">
                    <span className="text-amber-500 font-bold">5.0</span>
                    <div className="flex text-amber-500">
                      {[...Array(5)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
                    </div>
                    <span className="text-slate-400 text-sm ml-1">{t.contact.google_reviews}</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center text-blue-600">
                  <MapPin size={24} />
                </div>
              </div>
              
              <div className="border-t border-b border-slate-100 py-6 my-6 space-y-4">
                <div className="flex items-center gap-3 text-sm text-slate-600">
                  <MapPin size={18} className="text-slate-400" />
                  {t.contact.address}
                </div>
                <div className="flex items-center gap-3 text-sm text-slate-600">
                  <Phone size={18} className="text-slate-400" />
                  {t.contact.phone}
                </div>
                <div className="flex items-center gap-3 text-sm text-slate-600">
                  <Clock size={18} className="text-slate-400" />
                  {t.contact.google_open}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <a href={GOOGLE_MAPS_LINK} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 p-4 rounded-xl border border-slate-100 hover:bg-slate-50 transition-colors">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
                    <MapPin size={20} />
                  </div>
                  <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">{t.contact.cta_maps}</span>
                </a>
                <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 p-4 rounded-xl border border-slate-100 hover:bg-slate-50 transition-colors">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                    <WhatsAppIcon size={20} />
                  </div>
                  <span className="text-xs font-bold text-green-600 uppercase tracking-wider">{t.contact.cta_wa}</span>
                </a>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Instagram */}
        <section className="py-24 bg-slate-50">
          <div className="max-w-7xl mx-auto px-6 text-center">
            <motion.div {...fadeIn}>
              <Instagram size={48} className="mx-auto mb-6 text-pharmacy-accent" />
              <h2 className="font-display text-3xl font-bold mb-4">Síguenos en Instagram</h2>
              <p className="text-slate-500 mb-10">Mantente al día con nuestros consejos de salud y novedades.</p>
              <a 
                href="https://instagram.com/mypharmacypc" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="btn-accent mx-auto w-fit"
              >
                @mypharmacypc
              </a>
            </motion.div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 text-white py-32">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-20 mb-24">
            <div className="col-span-1 lg:col-span-2">
              <Logo />
              <p className="text-slate-400 text-xl max-w-md leading-relaxed mt-10 font-light italic">
                {t.footer.desc}
              </p>
            </div>
            <div>
              <h4 className="font-display font-bold text-lg mb-8 italic text-pharmacy-green">{t.footer.explore}</h4>
              <ul className="space-y-5 text-slate-400 font-light">
                <li><a href="#home" className="hover:text-white transition-colors">{t.nav.home}</a></li>
                <li><a href="#historia" className="hover:text-white transition-colors">{t.nav.legacy}</a></li>
                <li><a href="#instalaciones" className="hover:text-white transition-colors">{t.nav.facilities}</a></li>
                <li><a href="#productos" className="hover:text-white transition-colors">{t.nav.boutique}</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-display font-bold text-lg mb-8 italic text-pharmacy-purple">{t.footer.contact}</h4>
              <ul className="space-y-5 text-slate-400 font-light">
                <li className="flex items-start gap-4">
                  <MapPin size={20} className="text-pharmacy-green shrink-0" />
                  <span>{t.contact.address}</span>
                </li>
                <li className="flex items-center gap-4">
                  <Phone size={20} className="text-pharmacy-green shrink-0" />
                  <span>{t.contact.phone}</span>
                </li>
                <li className="flex items-center gap-4">
                  <Clock size={20} className="text-pharmacy-green shrink-0" />
                  <span>{t.contact.hours}</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-sm text-slate-500 font-light">
            <p>© {new Date().getFullYear()} My Pharmacy RD. {t.footer.rights}</p>
            <div className="flex gap-10">
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors flex items-center gap-2">
                <WhatsAppIcon size={18} />
                WhatsApp
              </a>
              <a href="https://instagram.com/mypharmacypc" className="hover:text-white transition-colors flex items-center gap-2">
                <Instagram size={18} />
                @mypharmacypc
              </a>
              <a href="#" className="hover:text-white transition-colors">{t.footer.privacy}</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
